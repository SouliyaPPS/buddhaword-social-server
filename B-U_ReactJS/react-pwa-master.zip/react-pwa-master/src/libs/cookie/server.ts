const serverCookieManager: any = {};

export default serverCookieManager;
